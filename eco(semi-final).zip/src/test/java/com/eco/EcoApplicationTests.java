package com.eco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoApplicationTests {

	@Test
	void contextLoads() {
	}

}
