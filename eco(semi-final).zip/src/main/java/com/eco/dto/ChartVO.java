package com.eco.dto;

import lombok.Data;

@Data
public class ChartVO {
    private int cseq;
    private String title;
    private String img = "";
}