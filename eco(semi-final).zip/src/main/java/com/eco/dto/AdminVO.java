package com.eco.dto;

import lombok.Data;

@Data
public class AdminVO {
	private int aseq;
	private String id;
	private String pw;	
}
