package com.eco.dto;

import lombok.Data;

@Data
public class ThemeVO {
	private int tseq;
	private String title;
	private String img = "";
}