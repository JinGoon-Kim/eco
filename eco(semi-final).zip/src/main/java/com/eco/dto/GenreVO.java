package com.eco.dto;

import lombok.Data;

@Data
public class GenreVO {
    private int gseq;
    private String title;
    private String img = "";
}