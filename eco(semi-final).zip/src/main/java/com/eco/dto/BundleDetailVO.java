package com.eco.dto;

import lombok.Data;

@Data
public class BundleDetailVO {
	private int bdseq;
    private int bmseq;
    private int mseq;
}
