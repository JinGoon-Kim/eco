package com.eco.admin.service;

public interface IAdminService {
	public int adminCheck(String adminId, String adminPw);
}