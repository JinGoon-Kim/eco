-- if sqlplus connect by system

create user eco identified by eco;
grant dba to eco;